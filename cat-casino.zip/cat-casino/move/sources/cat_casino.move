/// Hypeout Cat Casino on Supra L1.
///
/// Stake Hypeout ($HOT), Supra dVRF spins a 10-slot wheel, and you are paid stake x the multiplier
/// of the slot it lands on. Your lucky number is cosmetic: the cat looks at it, the wheel decides.
///
///  * Each slot has its own win chance and multiplier. Slots that pay 0x are the most common,
///    and the top slot is about 1 in a million. The table averages about 87% back to players
///    (`check_table` refuses anything above 90%), so the casino keeps a margin on every bet.
///  * Bank protection: before a bet is accepted, a slice of the free bankroll is reserved for it
///    (at most 10%). A payout can never exceed that reservation, and a bet is refused if the bank
///    cannot cover at least 20x the stake. The bank cannot be drained by one lucky spin.
///  * Cashback: every bet earns a small percent of its stake back (0.5% by default).
///  * Bets of at least `qualify_stake` (1,000 HOT) are QUALIFYING bets. Only qualifying bets
///      - feed the Jackpot (2%) and the Lottery prize (1%),
///      - roll for the Jackpot, and the chance rises every day nobody has hit it,
///      - count toward free lottery tickets (one ticket per `ticket_every` qualifying rounds).
///  * Lottery tickets are entered into a scheduled draw, also resolved with Supra dVRF.
///  * All payouts are credited to a `claimable` balance and pulled with `claim`. A Move callback
///    cannot catch a failed transfer, so paying inside the Supra callback could make the callback
///    abort and strand the round.
///
/// One Supra request per bet returns 2 random numbers: [0] spins the wheel, [1] jackpot roll.
module hypeout_cat::cat_casino {
    use std::signer;
    use std::string;
    use std::vector;
    use aptos_std::table::{Self, Table};
    use supra_framework::event;
    use supra_framework::fungible_asset::Metadata;
    use supra_framework::object::{Self, ExtendRef, Object};
    use supra_framework::primary_fungible_store;
    use supra_framework::timestamp;
    use supra_addr::deposit::{Self, SupraVRFPermit};
    use supra_addr::supra_vrf;

    // ------------------------------------------------------------------ constants
    const NUMBERS: u64 = 10;
    const JACKPOT_BPS: u64 = 200; // 2% of qualifying stakes
    const LOTTERY_BPS: u64 = 100; // 1% of qualifying stakes
    const BPS: u64 = 10000;
    const PPM: u64 = 1000000;
    const MAX_RTP_BPS: u64 = 9000; // the wheel can never return more than 90% on average
    const MAX_MULT_X100: u64 = 2000000; // no slot may pay more than 20,000x
    const EXPOSURE_BPS: u64 = 1000; // one bet may reserve at most 10% of the free bankroll
    const MIN_COVER: u64 = 20; // a bet is refused unless the bank can cover 20x its stake
    const DAY: u64 = 86400;
    const STALE_AFTER: u64 = 3600; // seconds before a stuck request can be unwound

    const KIND_BET: u8 = 1;
    const KIND_DRAW: u8 = 2;

    // ------------------------------------------------------------------ errors
    const E_NOT_ADMIN: u64 = 1;
    const E_BAD_PICK: u64 = 2;
    const E_STAKE_RANGE: u64 = 3;
    const E_BANKROLL: u64 = 4;
    const E_NOT_ENOUGH_TICKETS: u64 = 5;
    const E_DRAW_PENDING: u64 = 6;
    const E_TOO_EARLY: u64 = 7;
    const E_NOT_PENDING: u64 = 8;
    const E_NOT_STALE: u64 = 9;
    const E_NOTHING_TO_CLAIM: u64 = 10;
    const E_BAD_TABLE: u64 = 11;
    const E_BAD_LIMITS: u64 = 12;
    const E_BAD_CALLER: u64 = 13;
    const E_EXCEEDS_FREE: u64 = 14;
    const E_BAD_PARAM: u64 = 15;
    const E_ALREADY_INIT: u64 = 16;

    // ------------------------------------------------------------------ types
    /// Marker type used to register this module with Supra dVRF (`init_vrf_module<CatCasino>`).
    struct CatCasino has drop {}

    struct PermitCap has key {
        permit: SupraVRFPermit<CatCasino>,
    }

    struct Request has store, drop {
        kind: u8,
        qualified: bool,
        created_at: u64,
        player: address,
        pick: u8,   // lucky number (cosmetic)
        stake: u64,
        cap: u64,   // most this bet can ever pay, reserved from the bankroll when it was placed
    }

    struct PlayerStats has store, drop {
        completed: u64,
        qualified: u64,
        tickets: u64,
    }

    struct Winner has store, drop, copy {
        player: address,
        amount: u64,
        time: u64,
    }

    struct Entry has store, drop, copy {
        player: address,
        cumulative: u64, // total entries up to and including this one
    }

    struct EntryKey has store, drop, copy {
        draw: u64,
        who: address,
    }

    struct Game has key {
        hot: Object<Metadata>,
        vault: ExtendRef,
        vault_addr: address,

        qualify_stake: u64,
        min_bet: u64,
        max_bet: u64,
        jackpot_base_ppm: u64, // jackpot chance per qualifying bet today = base + step * days since last hit
        jackpot_step_ppm: u64,
        jackpot_cap_ppm: u64,
        last_jackpot_time: u64,
        cashback_bps: u64,
        ticket_every: u64,
        draw_interval: u64,
        num_confirmations: u64,

        // per-slot landing chance (parts per million, sums to 1,000,000) and multiplier (x100, 350 = 3.5x)
        weights: vector<u64>,
        mults: vector<u64>,

        jackpot_pool: u64,
        lottery_pool: u64,
        reserved: u64,        // bankroll set aside for pending bets
        claimable_total: u64, // payouts waiting to be claimed
        claimable: Table<address, u64>,

        requests: Table<u64, Request>, // supra nonce => request
        client_seed: u64,

        players: Table<address, PlayerStats>,
        unique_players: u64,
        total_rounds: u64,

        winners: vector<Winner>, // newest first, max 10
        jackpots_hit: u64,

        draw_id: u64,
        next_draw_time: u64,
        draw_pending: bool,
        entries: Table<u64, vector<Entry>>,
        total_entries: Table<u64, u64>,
        my_entries: Table<EntryKey, u64>,
    }

    // ------------------------------------------------------------------ events
    #[event]
    struct BetPlaced has drop, store { nonce: u64, player: address, pick: u8, stake: u64, qualified: bool }
    #[event]
    struct RoundResolved has drop, store {
        nonce: u64, player: address, lucky_pick: u8, drawn_number: u8, multiplier_x100: u64,
        stake: u64, payout: u64, cashback: u64, qualified: bool, jackpot_hit: bool, jackpot_amount: u64,
    }
    #[event]
    struct JackpotHit has drop, store { player: address, amount: u64, nonce: u64 }
    #[event]
    struct TicketAwarded has drop, store { player: address, ticket_balance: u64 }
    #[event]
    struct LotteryEntered has drop, store { draw_id: u64, player: address, count: u64 }
    #[event]
    struct LotteryDrawRequested has drop, store { draw_id: u64, nonce: u64 }
    #[event]
    struct LotteryDrawn has drop, store { draw_id: u64, winner: address, prize: u64, entries: u64 }
    #[event]
    struct LotteryRolledOver has drop, store { draw_id: u64, next_draw_time: u64 }
    #[event]
    struct StaleRecovered has drop, store { nonce: u64, player: address }

    // ------------------------------------------------------------------ setup
    /// Runs once when the package is published by the whitelisted wallet.
    fun init_module(sender: &signer) {
        let permit = deposit::init_vrf_module<CatCasino>(sender);
        move_to(sender, PermitCap { permit });
    }

    /// One-time game setup. Amounts are in HOT base units, so 1,000 HOT = 1000 * 10^decimals.
    public entry fun initialize(
        admin: &signer,
        hot_metadata: address,
        qualify_stake: u64,
        min_bet: u64,
        max_bet: u64,
    ) {
        assert_admin(admin);
        assert!(!exists<Game>(@hypeout_cat), E_ALREADY_INIT);
        assert!(min_bet > 0 && max_bet >= min_bet, E_BAD_LIMITS);
        assert!(qualify_stake >= min_bet && qualify_stake <= max_bet, E_BAD_LIMITS);

        let ctor = object::create_named_object(admin, b"hypeout_cat_vault");
        let vault = object::generate_extend_ref(&ctor);
        let vault_addr = object::address_from_constructor_ref(&ctor);

        // Number:      1     2    3     4     5       6      7     8     9     10
        // Multiplier:  3.5x  0x   10x   0.5x  900x    1.2x   18x   2.2x  90x   10,000x
        // Lands:       3%    50%  1%    30%   0.01%   10.39% 0.5%  5%    0.1%  0.0001%
        let weights = vector[30000, 500000, 10000, 300000, 100, 103899, 5000, 50000, 1000, 1];
        let mults = vector[350, 0, 1000, 50, 90000, 120, 1800, 220, 9000, 1000000];
        check_table(&weights, &mults);

        move_to(admin, Game {
            hot: object::address_to_object<Metadata>(hot_metadata),
            vault,
            vault_addr,
            qualify_stake,
            min_bet,
            max_bet,
            jackpot_base_ppm: 50,   // 0.005% per qualifying bet on day 0
            jackpot_step_ppm: 25,   // +0.0025% for every day the jackpot has not been hit
            jackpot_cap_ppm: 5000,  // never above 0.5%
            last_jackpot_time: timestamp::now_seconds(),
            cashback_bps: 50,       // 0.5% of every stake back to the player
            ticket_every: 5,
            draw_interval: 86400,
            num_confirmations: 1,
            weights,
            mults,
            jackpot_pool: 0,
            lottery_pool: 0,
            reserved: 0,
            claimable_total: 0,
            claimable: table::new(),
            requests: table::new(),
            client_seed: 0,
            players: table::new(),
            unique_players: 0,
            total_rounds: 0,
            winners: vector::empty(),
            jackpots_hit: 0,
            draw_id: 1,
            next_draw_time: timestamp::now_seconds() + 86400,
            draw_pending: false,
            entries: table::new(),
            total_entries: table::new(),
            my_entries: table::new(),
        });
    }

    // ------------------------------------------------------------------ play
    public entry fun place_bet(player: &signer, pick: u8, stake: u64) acquires Game, PermitCap {
        let g = borrow_global_mut<Game>(@hypeout_cat);
        assert!((pick as u64) >= 1 && (pick as u64) <= NUMBERS, E_BAD_PICK);
        assert!(stake >= g.min_bet && stake <= g.max_bet, E_STAKE_RANGE);
        let who = signer::address_of(player);

        primary_fungible_store::transfer(player, g.hot, g.vault_addr, stake);

        let qualified = stake >= g.qualify_stake;
        if (qualified) {
            g.jackpot_pool = g.jackpot_pool + mul_div(stake, JACKPOT_BPS, BPS);
            g.lottery_pool = g.lottery_pool + mul_div(stake, LOTTERY_BPS, BPS);
        };

        // Reserve what this bet could win, but never more than 10% of the free bankroll.
        let cap = mul_div(house_free(g), EXPOSURE_BPS, BPS);
        let want = mul_div(stake, max_mult(g), 100);
        let reserve = if (want < cap) { want } else { cap };
        assert!(reserve >= stake * MIN_COVER, E_BANKROLL);
        g.reserved = g.reserved + reserve;

        // 2 numbers: [0] winning number, [1] jackpot roll
        g.client_seed = g.client_seed + 1;
        let permit = &borrow_global<PermitCap>(@hypeout_cat).permit;
        let nonce = supra_vrf::rng_request_v2<CatCasino>(
            permit,
            string::utf8(b"on_random"),
            2,
            g.client_seed,
            g.num_confirmations,
        );
        table::add(&mut g.requests, nonce, Request {
            kind: KIND_BET,
            qualified,
            created_at: timestamp::now_seconds(),
            player: who,
            pick,
            stake,
            cap: reserve,
        });

        if (!table::contains(&g.players, who)) {
            table::add(&mut g.players, who, PlayerStats { completed: 0, qualified: 0, tickets: 0 });
            g.unique_players = g.unique_players + 1;
        };
        event::emit(BetPlaced { nonce, player: who, pick, stake, qualified });
    }

    // ------------------------------------------------------------------ lottery
    public entry fun enter_lottery(player: &signer, count: u64) acquires Game {
        let g = borrow_global_mut<Game>(@hypeout_cat);
        assert!(!g.draw_pending, E_DRAW_PENDING);
        let who = signer::address_of(player);
        assert!(table::contains(&g.players, who), E_NOT_ENOUGH_TICKETS);
        let stats = table::borrow_mut(&mut g.players, who);
        assert!(count > 0 && count <= stats.tickets, E_NOT_ENOUGH_TICKETS);
        stats.tickets = stats.tickets - count;

        let id = g.draw_id;
        let total_ref = table::borrow_mut_with_default(&mut g.total_entries, id, 0);
        *total_ref = *total_ref + count;
        let total = *total_ref;
        let mine = table::borrow_mut_with_default(&mut g.my_entries, EntryKey { draw: id, who }, 0);
        *mine = *mine + count;
        let list = table::borrow_mut_with_default(&mut g.entries, id, vector::empty<Entry>());
        vector::push_back(list, Entry { player: who, cumulative: total });
        event::emit(LotteryEntered { draw_id: id, player: who, count });
    }

    /// Anyone (a keeper bot or a player) can trigger the scheduled draw once the time has come.
    public entry fun request_draw(_caller: &signer) acquires Game, PermitCap {
        let g = borrow_global_mut<Game>(@hypeout_cat);
        assert!(timestamp::now_seconds() >= g.next_draw_time, E_TOO_EARLY);
        assert!(!g.draw_pending, E_DRAW_PENDING);

        let id = g.draw_id;
        let total = *table::borrow_mut_with_default(&mut g.total_entries, id, 0);
        if (total == 0) {
            g.next_draw_time = timestamp::now_seconds() + g.draw_interval;
            event::emit(LotteryRolledOver { draw_id: id, next_draw_time: g.next_draw_time });
            return
        };

        g.draw_pending = true;
        g.client_seed = g.client_seed + 1;
        let permit = &borrow_global<PermitCap>(@hypeout_cat).permit;
        let nonce = supra_vrf::rng_request_v2<CatCasino>(
            permit,
            string::utf8(b"on_random"),
            1,
            g.client_seed,
            g.num_confirmations,
        );
        table::add(&mut g.requests, nonce, Request {
            kind: KIND_DRAW,
            qualified: false,
            created_at: timestamp::now_seconds(),
            player: @0x0,
            pick: 0,
            stake: 0,
            cap: 0,
        });
        event::emit(LotteryDrawRequested { draw_id: id, nonce });
    }

    // ------------------------------------------------------------------ Supra callback
    /// Called by Supra with the random numbers. `verify_callback` proves they came from Supra's VRF,
    /// so never remove it and never reorder its arguments.
    public entry fun on_random(
        nonce: u64,
        message: vector<u8>,
        signature: vector<u8>,
        caller_address: address,
        rng_count: u8,
        client_seed: u64,
    ) acquires Game {
        let rng: vector<u256> = supra_vrf::verify_callback(
            nonce, message, signature, caller_address, rng_count, client_seed,
        );
        assert!(caller_address == @hypeout_cat, E_BAD_CALLER);

        let g = borrow_global_mut<Game>(@hypeout_cat);
        if (!table::contains(&g.requests, nonce)) return; // unknown, or already recovered
        let r = table::remove(&mut g.requests, nonce);
        if (r.kind == KIND_BET) {
            resolve_bet(g, nonce, &r, &rng);
        } else {
            resolve_draw(g, *vector::borrow(&rng, 0));
        };
    }

    /// Spin the wheel: walk the cumulative landing chances until the roll is covered.
    fun draw_number(g: &Game, rand: u256): u8 {
        let roll = ((rand % (PPM as u256)) as u64);
        let acc = 0;
        let i = 0;
        while (i < NUMBERS) {
            acc = acc + *vector::borrow(&g.weights, i);
            if (roll < acc) return ((i + 1) as u8);
            i = i + 1;
        };
        (NUMBERS as u8) // unreachable: weights sum to PPM
    }

    /// Jackpot chance per qualifying bet right now, in parts per million. Grows every day without a hit.
    fun jackpot_chance(g: &Game): u64 {
        let days = (timestamp::now_seconds() - g.last_jackpot_time) / DAY;
        let c = g.jackpot_base_ppm + g.jackpot_step_ppm * days;
        if (c > g.jackpot_cap_ppm) { g.jackpot_cap_ppm } else { c }
    }

    fun resolve_bet(g: &mut Game, nonce: u64, r: &Request, rng: &vector<u256>) {
        let drawn = draw_number(g, *vector::borrow(rng, 0));
        let mult = *vector::borrow(&g.mults, (drawn as u64) - 1);
        let raw = mul_div(r.stake, mult, 100);
        let paid = if (raw < r.cap) { raw } else { r.cap }; // never more than was reserved
        let player = r.player;

        g.reserved = g.reserved - r.cap;
        g.total_rounds = g.total_rounds + 1;
        credit(g, player, paid);

        // cashback on every bet, win or lose
        let cashback = mul_div(r.stake, g.cashback_bps, BPS);
        credit(g, player, cashback);

        // the jackpot is rolled on every QUALIFYING bet, whatever the wheel did
        let jp = false;
        let jp_amount = 0;
        if (r.qualified && g.jackpot_pool > 0) {
            let roll = ((*vector::borrow(rng, 1) % (PPM as u256)) as u64);
            if (roll < jackpot_chance(g)) {
                jp = true;
                jp_amount = g.jackpot_pool;
                g.jackpot_pool = 0;
                g.last_jackpot_time = timestamp::now_seconds();
                vector::insert(&mut g.winners, 0, Winner { player, amount: jp_amount, time: timestamp::now_seconds() });
                if (vector::length(&g.winners) > 10) { vector::pop_back(&mut g.winners); };
                g.jackpots_hit = g.jackpots_hit + 1;
                credit(g, player, jp_amount);
                event::emit(JackpotHit { player, amount: jp_amount, nonce });
            };
        };

        let ticket_every = g.ticket_every;
        let stats = table::borrow_mut(&mut g.players, player);
        stats.completed = stats.completed + 1;
        if (r.qualified) {
            stats.qualified = stats.qualified + 1;
            if (stats.qualified % ticket_every == 0) {
                stats.tickets = stats.tickets + 1;
                event::emit(TicketAwarded { player, ticket_balance: stats.tickets });
            };
        };

        event::emit(RoundResolved {
            nonce, player, lucky_pick: r.pick, drawn_number: drawn, multiplier_x100: mult,
            stake: r.stake, payout: paid, cashback, qualified: r.qualified, jackpot_hit: jp, jackpot_amount: jp_amount,
        });
    }

    fun resolve_draw(g: &mut Game, rand: u256) {
        let id = g.draw_id;
        let total = *table::borrow(&g.total_entries, id);
        let target = ((rand % (total as u256)) as u64); // 0..total-1

        let winner = {
            let e = table::borrow(&g.entries, id);
            let lo = 0;
            let hi = vector::length(e) - 1;
            while (lo < hi) {
                let mid = (lo + hi) / 2;
                let en = vector::borrow(e, mid);
                if (en.cumulative > target) { hi = mid } else { lo = mid + 1 };
            };
            let w = vector::borrow(e, lo);
            w.player
        };

        let prize = g.lottery_pool;
        g.lottery_pool = 0;
        g.draw_pending = false;
        g.draw_id = id + 1;
        g.next_draw_time = timestamp::now_seconds() + g.draw_interval;

        credit(g, winner, prize);
        event::emit(LotteryDrawn { draw_id: id, winner, prize, entries: total });
    }

    // ------------------------------------------------------------------ payouts
    fun credit(g: &mut Game, to: address, amount: u64) {
        if (amount == 0) return;
        let cur = table::borrow_mut_with_default(&mut g.claimable, to, 0);
        *cur = *cur + amount;
        g.claimable_total = g.claimable_total + amount;
    }

    /// Move everything you have won (bets, jackpot, lottery, refunds) to your wallet.
    public entry fun claim(player: &signer) acquires Game {
        let g = borrow_global_mut<Game>(@hypeout_cat);
        let who = signer::address_of(player);
        assert!(table::contains(&g.claimable, who), E_NOTHING_TO_CLAIM);
        let amt = table::remove(&mut g.claimable, who);
        assert!(amt > 0, E_NOTHING_TO_CLAIM);
        g.claimable_total = g.claimable_total - amt;
        let vault_signer = object::generate_signer_for_extending(&g.vault);
        primary_fungible_store::transfer(&vault_signer, g.hot, who, amt);
    }

    // ------------------------------------------------------------------ safety valve
    /// If Supra never answers, anyone can unwind the request after one hour.
    /// Bets are refunded in full; a stuck lottery draw is re-opened.
    public entry fun recover_stale(_caller: &signer, nonce: u64) acquires Game {
        let g = borrow_global_mut<Game>(@hypeout_cat);
        assert!(table::contains(&g.requests, nonce), E_NOT_PENDING);
        let created = table::borrow(&g.requests, nonce).created_at;
        assert!(timestamp::now_seconds() >= created + STALE_AFTER, E_NOT_STALE);
        let r = table::remove(&mut g.requests, nonce);

        if (r.kind == KIND_BET) {
            g.reserved = g.reserved - r.cap;
            if (r.qualified) {
                g.jackpot_pool = g.jackpot_pool - mul_div(r.stake, JACKPOT_BPS, BPS);
                g.lottery_pool = g.lottery_pool - mul_div(r.stake, LOTTERY_BPS, BPS);
            };
            credit(g, r.player, r.stake);
            event::emit(StaleRecovered { nonce, player: r.player });
        } else {
            g.draw_pending = false;
            event::emit(StaleRecovered { nonce, player: @0x0 });
        };
    }

    // ------------------------------------------------------------------ admin
    fun assert_admin(s: &signer) {
        assert!(signer::address_of(s) == @hypeout_cat, E_NOT_ADMIN);
    }

    fun check_table(w: &vector<u64>, m: &vector<u64>) {
        assert!(vector::length(w) == NUMBERS && vector::length(m) == NUMBERS, E_BAD_TABLE);
        let sum = 0;
        let ret = 0u128; // sum(chance_ppm * mult_x100): 1e8 equals 100% average return
        let i = 0;
        while (i < NUMBERS) {
            let wi = *vector::borrow(w, i);
            let mi = *vector::borrow(m, i);
            assert!(wi > 0 && mi <= MAX_MULT_X100, E_BAD_TABLE); // a slot may pay 0x, but must be reachable
            sum = sum + wi;
            ret = ret + (wi as u128) * (mi as u128);
            i = i + 1;
        };
        assert!(sum == PPM, E_BAD_TABLE);
        assert!(ret / 10000 <= (MAX_RTP_BPS as u128), E_BAD_TABLE); // average return in bps
    }

    public entry fun set_table(admin: &signer, weights: vector<u64>, mults: vector<u64>) acquires Game {
        assert_admin(admin);
        check_table(&weights, &mults);
        let g = borrow_global_mut<Game>(@hypeout_cat);
        g.weights = weights;
        g.mults = mults;
    }

    public entry fun fund_house(admin: &signer, amount: u64) acquires Game {
        assert_admin(admin);
        let g = borrow_global<Game>(@hypeout_cat);
        primary_fungible_store::transfer(admin, g.hot, g.vault_addr, amount);
    }

    public entry fun seed_jackpot(admin: &signer, amount: u64) acquires Game {
        assert_admin(admin);
        let g = borrow_global_mut<Game>(@hypeout_cat);
        primary_fungible_store::transfer(admin, g.hot, g.vault_addr, amount);
        g.jackpot_pool = g.jackpot_pool + amount;
    }

    public entry fun seed_lottery(admin: &signer, amount: u64) acquires Game {
        assert_admin(admin);
        let g = borrow_global_mut<Game>(@hypeout_cat);
        primary_fungible_store::transfer(admin, g.hot, g.vault_addr, amount);
        g.lottery_pool = g.lottery_pool + amount;
    }

    public entry fun withdraw_house(admin: &signer, amount: u64) acquires Game {
        assert_admin(admin);
        let g = borrow_global<Game>(@hypeout_cat);
        assert!(amount <= house_free(g), E_EXCEEDS_FREE);
        let vault_signer = object::generate_signer_for_extending(&g.vault);
        primary_fungible_store::transfer(&vault_signer, g.hot, signer::address_of(admin), amount);
    }

    public entry fun set_limits(admin: &signer, qualify_stake: u64, min_bet: u64, max_bet: u64) acquires Game {
        assert_admin(admin);
        assert!(min_bet > 0 && max_bet >= min_bet, E_BAD_LIMITS);
        assert!(qualify_stake >= min_bet && qualify_stake <= max_bet, E_BAD_LIMITS);
        let g = borrow_global_mut<Game>(@hypeout_cat);
        g.qualify_stake = qualify_stake;
        g.min_bet = min_bet;
        g.max_bet = max_bet;
    }

    /// Jackpot chance per qualifying bet today = base + step * days since the last hit, capped. All in ppm.
    public entry fun set_jackpot_curve(admin: &signer, base_ppm: u64, step_ppm: u64, cap_ppm: u64) acquires Game {
        assert_admin(admin);
        assert!(base_ppm <= cap_ppm && cap_ppm <= 100000, E_BAD_PARAM);
        let g = borrow_global_mut<Game>(@hypeout_cat);
        g.jackpot_base_ppm = base_ppm;
        g.jackpot_step_ppm = step_ppm;
        g.jackpot_cap_ppm = cap_ppm;
    }

    public entry fun set_cashback(admin: &signer, bps: u64) acquires Game {
        assert_admin(admin);
        assert!(bps <= 200, E_BAD_PARAM); // at most 2%
        borrow_global_mut<Game>(@hypeout_cat).cashback_bps = bps;
    }

    public entry fun set_ticket_every(admin: &signer, n: u64) acquires Game {
        assert_admin(admin);
        assert!(n >= 1 && n <= 1000, E_BAD_PARAM);
        borrow_global_mut<Game>(@hypeout_cat).ticket_every = n;
    }

    public entry fun set_draw_interval(admin: &signer, secs: u64) acquires Game {
        assert_admin(admin);
        assert!(secs >= 3600, E_BAD_PARAM);
        borrow_global_mut<Game>(@hypeout_cat).draw_interval = secs;
    }

    public entry fun set_confirmations(admin: &signer, n: u64) acquires Game {
        assert_admin(admin);
        assert!(n >= 1 && n <= 20, E_BAD_PARAM);
        borrow_global_mut<Game>(@hypeout_cat).num_confirmations = n;
    }

    // ------------------------------------------------------------------ helpers
    fun mul_div(a: u64, b: u64, c: u64): u64 {
        (((a as u128) * (b as u128) / (c as u128)) as u64)
    }

    fun max_mult(g: &Game): u64 {
        let best = 0;
        let i = 0;
        while (i < NUMBERS) {
            let m = *vector::borrow(&g.mults, i);
            if (m > best) { best = m };
            i = i + 1;
        };
        best
    }

    /// HOT the house can lose without touching jackpot, lottery or pending liabilities.
    fun house_free(g: &Game): u64 {
        let bal = primary_fungible_store::balance(g.vault_addr, g.hot);
        let locked = g.jackpot_pool + g.lottery_pool + g.reserved + g.claimable_total;
        if (bal > locked) { bal - locked } else { 0 }
    }

    // ------------------------------------------------------------------ views
    #[view]
    public fun house_free_view(): u64 acquires Game {
        house_free(borrow_global<Game>(@hypeout_cat))
    }

    /// (jackpot, lottery, unique players, next draw time, draw pending, draw id)
    #[view]
    public fun radar(): (u64, u64, u64, u64, bool, u64) acquires Game {
        let g = borrow_global<Game>(@hypeout_cat);
        (g.jackpot_pool, g.lottery_pool, g.unique_players, g.next_draw_time, g.draw_pending, g.draw_id)
    }

    /// (qualify stake, min bet, max bet, tickets every N qualifying rounds, cashback bps)
    #[view]
    public fun rules(): (u64, u64, u64, u64, u64) acquires Game {
        let g = borrow_global<Game>(@hypeout_cat);
        (g.qualify_stake, g.min_bet, g.max_bet, g.ticket_every, g.cashback_bps)
    }

    /// Today's jackpot chance per qualifying bet, in parts per million.
    #[view]
    public fun jackpot_chance_ppm(): u64 acquires Game {
        jackpot_chance(borrow_global<Game>(@hypeout_cat))
    }

    /// The biggest stake the bank will accept right now.
    #[view]
    public fun max_stake_now(): u64 acquires Game {
        let g = borrow_global<Game>(@hypeout_cat);
        let by_bank = mul_div(house_free(g), EXPOSURE_BPS, BPS) / MIN_COVER;
        if (by_bank < g.max_bet) { by_bank } else { g.max_bet }
    }

    /// (landing chances in ppm, multipliers x100) for numbers 1..10
    #[view]
    public fun table_view(): (vector<u64>, vector<u64>) acquires Game {
        let g = borrow_global<Game>(@hypeout_cat);
        (g.weights, g.mults)
    }

    #[view]
    public fun recent_winners(): vector<Winner> acquires Game {
        borrow_global<Game>(@hypeout_cat).winners
    }

    /// (tickets, completed rounds, qualifying rounds, qualifying rounds to next ticket, claimable HOT, entries this draw)
    #[view]
    public fun player_info(who: address): (u64, u64, u64, u64, u64, u64) acquires Game {
        let g = borrow_global<Game>(@hypeout_cat);
        let (tickets, completed, qualified) = if (table::contains(&g.players, who)) {
            let s = table::borrow(&g.players, who);
            (s.tickets, s.completed, s.qualified)
        } else { (0, 0, 0) };
        let claimable = if (table::contains(&g.claimable, who)) { *table::borrow(&g.claimable, who) } else { 0 };
        let key = EntryKey { draw: g.draw_id, who };
        let entries = if (table::contains(&g.my_entries, key)) { *table::borrow(&g.my_entries, key) } else { 0 };
        (tickets, completed, qualified, g.ticket_every - (qualified % g.ticket_every), claimable, entries)
    }
}
