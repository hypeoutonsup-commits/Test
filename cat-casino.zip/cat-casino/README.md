# Hypeout Cat Casino ($HOT)

Pick a number from 1 to 10, bet Hypeout ($HOT), and a fire-cat reacts while Supra dVRF decides the result. Built for Supra L1 in Move.

```
move/       Move package: game, jackpot, lottery, Supra dVRF consumer
preview/    index.html, the clickable preview (open it in any browser, no server needed)
```

## How a round works

You pick a lucky number (the cat looks at it), stake $HOT, and Supra dVRF spins a 10-slot wheel. You are paid your stake times the multiplier of the slot it lands on. Half the time it lands on a 0x slot.

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| Pays | 3.5x | 0x | 10x | 0.5x | 900x | 1.2x | 18x | 2.2x | 90x | 10,000x |
| Lands | 3% | 50% | 1% | 30% | 0.01% | 10.39% | 0.5% | 5% | 0.1% | 0.0001% |

The wheel averages 87% back to players (a 2-million-spin simulation gave 87.4%). The contract refuses any table above 90%, and the admin can change the table with `set_table`.

## How the casino stays profitable and solvent

- **Edge:** the wheel keeps about 13%. Cashback (0.5%) and, for qualifying bets, the jackpot and lottery shares (3%) are paid back to players, so the casino keeps about 9.5% of qualifying volume and 12.5% of smaller bets.
- **Bank protection:** before a bet is accepted the contract reserves what it could win, capped at 10% of the free bankroll. A payout can never exceed that reservation, and a bet is refused unless the bank can cover 20x the stake. One lucky spin cannot drain the bank, and the largest accepted stake shrinks as the bank shrinks (`max_stake_now`). To offer the full 10,000x on a 1,000 $HOT bet the free bankroll needs to be about 100 million $HOT; with less, the top prize is simply capped at 10% of it.
- **Jackpot and lottery pools** are funded only by player stakes and never touch the bank.

## Cashback, jackpot and lottery

- **Cashback:** every bet earns 0.5% of its stake back (`set_cashback`, max 2%).
- **Qualifying bets:** a bet of **1,000 $HOT or more**. Only these feed the Jackpot (2%) and the Lottery prize (1%), roll for the Jackpot, and count toward free tickets. Smaller bets still spin the wheel and still earn cashback.
- **Jackpot chance grows every day:** per qualifying bet it is 0.005% on day 0, plus 0.0025% for each day nobody has hit it, capped at 0.5%. A hit pays the whole pool and resets the clock (`set_jackpot_curve`, `jackpot_chance_ppm` view).
- **Free tickets:** every 5 qualifying rounds (`set_ticket_every`).
- **Lottery:** enter tickets with `enter_lottery`. Once the draw time passes, anyone or a keeper bot calls `request_draw`, and Supra picks the winner.
- **Claiming:** wins, cashback, the jackpot, the lottery prize and refunds go to a claimable balance, and players pull them with `claim`. Move cannot catch a failed transfer, so paying inside the Supra callback could abort the callback and strand the round.
- **Stuck rounds:** if Supra never answers, anyone can call `recover_stale(nonce)` after 1 hour. The bet is refunded.

## Deploy on Supra L1

1. Install the Supra CLI (v12 or newer) and run `supra move tool init` inside `move/`. Keep the SupraFramework block it writes if it differs from the one in `Move.toml`. For mainnet, switch the SupraVrf block to `subdir = "supra/mainnet"`, `rev = "master"`.
2. Whitelist your wallet for dVRF. This wallet becomes the module address, so use the wallet you will publish from:
   ```
   supra move tool run --function-id <VRF_ADDRESS>::deposit::whitelist_client_address --args u64:<MAX_TXN_FEE>
   ```
   `<VRF_ADDRESS>` is on Supra's "Available Versions and Networks" page. Pick the max fee after reading their Gas Configurations page.
3. Publish from that wallet. `init_module` registers the contract with dVRF:
   ```
   supra move tool publish --package-dir move --named-addresses hypeout_cat=<YOUR_WALLET>
   ```
4. Check registration with `<VRF_ADDRESS>::deposit::get_module_info` and the type `<YOUR_WALLET>::cat_casino::CatCasino`. The result should show `enabled`. If callbacks cost more than `max_callback_txn_fee`, raise it with `update_max_callback_txn_fee`.
5. Deposit SUPRA into your dVRF subscription for callback gas (Supra's "Deposit and Withdraw Funds" page). Requests are refused when the balance drops below the minimum.
6. Run `cat_casino::initialize` with the $HOT fungible-asset metadata address and amounts in base units. The address you sent, `0x9bb4f6c70d49c897927478291be2e5d4cd71b2599c3742672aa4f6a90c502d69`, is assumed to be the $HOT token (check it is the token's metadata object, not the game). For a token with 8 decimals, `qualify_stake` is `100000000000` (1,000 HOT).
7. Fund the bankroll with `fund_house`. Bets are rejected when the free bankroll cannot cover the largest possible payout. Optionally call `seed_jackpot` and `seed_lottery`.
8. Run a keeper that calls `request_draw` once `next_draw_time` has passed (`radar` view).

## Before real money

- **Not compiled, not tested, not audited.** No Supra CLI was available where this was written. Compile with `supra move tool compile`, write Move unit tests (bet, callback, jackpot reset, stale recovery, lottery with several entrants), and get an audit. Check gambling rules where you operate.
- The imports use `supra_framework::` and `aptos_std::` names. If the compiler disagrees with a module path, `supra move tool init` generates the right dependency block and the paths should follow it.
- It assumes $HOT is a fungible asset (the newer Supra token standard). If $HOT is a legacy `Coin`, the transfer calls change.
- The Supra callback name is `on_random`. Do not rename it or change its six parameters.
- The preview runs on a simulated chain with `Math.random`. The live site (StarKey wallet connection and calls into this module) is not built yet.
